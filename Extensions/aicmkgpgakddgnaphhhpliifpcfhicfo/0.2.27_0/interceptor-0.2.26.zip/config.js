var POSTMAN_APP_ID_PRODUCTION = "fhbjgbiflinjbdggehcddcbncdddomop";
var POSTMAN_APP_ID_STAGING = "mgicbpdmnpnfckafakeoiomkjcplfcld";
var POSTMAN_APP_ID_DEV = "aglpidefogoeiamaehklpfoafichfmdk";
var POSTMAN_APP_ID_SYNCSTAGE = "loddepljkabcghihdkbkfknabkinanff";
var POSTMAN_APP_ID_BETA = "haioananincdljfbnjpaiclamakiegam";
var POSTMAN_APP_ID_LOCAL = "ncnklfmibdifliimhgejlpjdhkdhhado";//"aglpidefogoeiamaehklpfoafichfmdk";

var postmanAppId = POSTMAN_APP_ID_PRODUCTION;